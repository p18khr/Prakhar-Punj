package com.training.nagarro.dao;

public interface ReadCsvFiles {
    void storeCsvData(); // retrieves and stores data as Tshirt object
}
